import { lazy } from 'react';
import { Navigate } from 'react-router-dom';
import ProtectedRoute from '../pages/Auth/ProtectedRoute';
import PublicRoute from '../pages/Auth/PublicRoute';
import LoginPage from '../pages/Auth/Login';
import Error404 from '../pages/Auth/404';

import BannerPage from '../pages/MasterData/Banner';
import ShiftPage from '../pages/MasterData/Shift';

import LokasiPage from '../pages/MasterData/Lokasi/Lokasi';
import LokasiCreatePage from '../pages/MasterData/Lokasi/CreateLokasi';
import LokasiEditPage from '../pages/MasterData/Lokasi/UpdateLokasi';

import JabatanPage from '../pages/MasterData/Jabatan';
import PegawaiPage from '../pages/MasterData/Employees/Employees';
import PegawaiCreatePage from '../pages/MasterData/Employees/CreateEmployees';
import PegawaiUpdatePage from '../pages/MasterData/Employees/UpdateEmployees';
import PegawaiErrorImportPage from '../pages/MasterData/Employees/ErrorImport';
import ThemaPage from '../pages/MasterData/ThemaCard';


import AreaPatroliPage from '../pages/Patroli/AreaPatroli';
import CheckpointsPage from '../pages/Patroli/Checkpoints/Checkpoints';
import CheckpointsCreatePage from '../pages/Patroli/Checkpoints/CreateCheckpoints';
import CheckpointsUpdatePage from '../pages/Patroli/Checkpoints/UpdateCheckpoints';

import MatrixPage from '../pages/Matrix/Matrix';
import QuestionsPage from '../pages/Matrix/Questions';
import QuestionsCreatePage from '../pages/Matrix/Questions/CreateQuestions';
import QuestionsUpdatePage from '../pages/Matrix/Questions/UpdateQuestions';


import TopicPage from '../pages/Msp/Topic';


const Index = lazy(() => import('../pages/Index'));

const routes = [
    // Halaman login (akses tanpa login)
    {
        path: '/auth/login',
        element: (
            <PublicRoute>
                <LoginPage />
            </PublicRoute>
        ),
        layout: 'blank',
    },
    // Dashboard utama (akses dengan login)
    {
        path: '/',
        element: (
            <ProtectedRoute>
                <Index />
            </ProtectedRoute>
        ),
    },
    // Rute master data (akses dengan login)
    {
        path: '/master-data/banner',
        element: (
            <ProtectedRoute>
                <BannerPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/master-data/shift',
        element: (
            <ProtectedRoute>
                <ShiftPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/master-data/lokasi',
        element: (
            <ProtectedRoute>
                <LokasiPage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/master-data/lokasi/create',
        element: (
            <ProtectedRoute>
                <LokasiCreatePage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/master-data/lokasi/edit/:id',
        element: (
            <ProtectedRoute>
                <LokasiEditPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/master-data/jabatan',
        element: (
            <ProtectedRoute>
                <JabatanPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/master-data/karyawan',
        element: (
            <ProtectedRoute>
                <PegawaiPage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/master-data/karyawan/create',
        element: (
            <ProtectedRoute>
                <PegawaiCreatePage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/master-data/karyawan/error-import',
        element: (
            <ProtectedRoute>
                <PegawaiErrorImportPage />
            </ProtectedRoute>
        ),
    },


    {
        path: '/master-data/karyawan/edit/:id',
        element: (
            <ProtectedRoute>
                <PegawaiUpdatePage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/master-data/thema-card',
        element: (
            <ProtectedRoute>
                <ThemaPage />
            </ProtectedRoute>
        ),
    },

    // Patroli
    {
        path: '/patroli/area-patroli',
        element: (
            <ProtectedRoute>
                <AreaPatroliPage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/patroli/checkpoints',
        element: (
            <ProtectedRoute>
                <CheckpointsPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/patroli/checkpoints/create',
        element: (
            <ProtectedRoute>
                <CheckpointsCreatePage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/patroli/checkpoints/edit/:id',
        element: (
            <ProtectedRoute>
                <CheckpointsUpdatePage />
            </ProtectedRoute>
        ),
    },

    // Matrix
    {
        path: '/matrix/matrix',
        element: (
            <ProtectedRoute>
                <MatrixPage />
            </ProtectedRoute>
        ),
    },
    {
        path: '/matrix/questions',
        element: (
            <ProtectedRoute>
                <QuestionsPage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/matrix/questions/create',
        element: (
            <ProtectedRoute>
                <QuestionsCreatePage />
            </ProtectedRoute>
        ),
    },

    {
        path: '/matrix/questions/edit/:id',
        element: (
            <ProtectedRoute>
                <QuestionsUpdatePage />
            </ProtectedRoute>
        ),
    },

    // MSP
    {
        path: '/msp/topic',
        element: (
            <ProtectedRoute>
                <TopicPage />
            </ProtectedRoute>
        ),
    },

    // Rute fallback (halaman tidak ditemukan)
    {
        path: '*',
        element: <Navigate to="/404" />,
    },
    {
        path: '/404',
        element: (
                <Error404 />
        ),
        layout: 'blank',
    },
];

export { routes };
