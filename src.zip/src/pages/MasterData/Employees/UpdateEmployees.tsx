import React, { useState, useEffect, Fragment } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

const API_EMPLOYEES = "https://sipandu.sinarjernihsuksesindo.biz.id/api/employees/";
const API_SHIFTS = "https://sipandu.sinarjernihsuksesindo.biz.id/api/shifts/";
const API_POSITIONS = "https://sipandu.sinarjernihsuksesindo.biz.id/api/positions/";
const API_CUSTOMERS = "https://sipandu.sinarjernihsuksesindo.biz.id/api/customers/";

const EditEmployee: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [formFields, setFormFields] = useState({
    employees_nip: "",
    employees_name: "",
    employees_email: "",
    password: "",
    position_id: "",
    shift_id: "",
    id_area_patroli: "",
    photo: null as File | null,
  });

  const [isSaving, setIsSaving] = useState(false); // Tambahkan state untuk tombol

   const [photoPreview, setPhotoPreview] = useState<string | null>(null);
    const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
    const [isDragAndDropVisible, setIsDragAndDropVisible] = useState(false);
    const [isUploadDisabled, setIsUploadDisabled] = useState(false);
    const [isCaptureDisabled, setIsCaptureDisabled] = useState(false);
  
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const [cameraFacingMode, setCameraFacingMode] = useState<"user" | "environment">("user");
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [isSwitchCameraAvailable, setIsSwitchCameraAvailable] = useState(false);
    const [isMobile, setIsMobile] = useState(false);

  const [positions, setPositions] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [penempatan, setPenempatan] = useState([]);

  useEffect(() => {
    fetchEmployeeData();
    fetchPositions();
    fetchShifts();
    fetchPenempatan();
  }, []);

  const fetchEmployeeData = async () => {
    try {
      const response = await axios.get(`${API_EMPLOYEES}${id}`);
      const data = response.data;
      setFormFields({
        employees_nip: data.employees_nip,
        employees_name: data.employees_name,
        employees_email: data.employees_email,
        password: "",
        position_id: data.position_id || "",
        shift_id: data.shift_id || "",
        id_area_patroli: data.customer_id || "",
        photo: null,
      });
  
      // Manipulasi URL foto jika tersedia
      if (data.photo) {
        // Pastikan URL absolut ditambahkan
        const updatedPhotoURL = `https://sipandu.sinarjernihsuksesindo.biz.id/${data.photo}`;
        setPhotoPreview(updatedPhotoURL);
      }
    } catch (error) {
      Swal.fire("Error!", "Gagal memuat data karyawan.", "error");
    }
  };
  
  

  const fetchPositions = async () => {
    try {
      const response = await axios.get(API_POSITIONS);
      setPositions(response.data);
    } catch (error) {
      Swal.fire("Error!", "Gagal memuat data posisi.", "error");
    }
  };

  const fetchShifts = async () => {
    try {
      const response = await axios.get(API_SHIFTS);
      setShifts(response.data);
    } catch (error) {
      Swal.fire("Error!", "Gagal memuat data shift.", "error");
    }
  };

  const fetchPenempatan = async () => {
    try {
      const response = await axios.get(API_CUSTOMERS);
      setPenempatan(response.data);
    } catch (error) {
      Swal.fire("Error!", "Gagal memuat data penempatan.", "error");
    }
  };

  const validateForm = () => {
    const { employees_nip, employees_name, employees_email, position_id, shift_id, id_area_patroli } = formFields;
    if (!employees_nip || !employees_name || !employees_email || !position_id || !shift_id || !id_area_patroli) {
      Swal.fire("Error!", "Semua kolom harus diisi!", "error");
      return false;
    }
    return true;
  };

  const handleUpdate = async () => {
    if (!validateForm()) return;
  
    setIsSaving(true); // Set tombol menjadi loading
  
    const formData = new FormData();
    formData.append("employees_nip", formFields.employees_nip);
    formData.append("employees_name", formFields.employees_name);
    formData.append("employees_email", formFields.employees_email);
    if (formFields.password) formData.append("password", formFields.password);
    formData.append("position_id", formFields.position_id);
    formData.append("shift_id", formFields.shift_id);
    formData.append("id_area_patroli", formFields.id_area_patroli);
    if (formFields.photo) formData.append("photo", formFields.photo);
  
    try {
      await axios.put(`${API_EMPLOYEES}${id}`, formData);
      Swal.fire("Berhasil!", "Data karyawan berhasil diperbarui!", "success");
      navigate("/master-data/karyawan");
    } catch (error) {
      let errorMessage = "Gagal memperbarui data karyawan.";
      if (error.response && error.response.data && error.response.data.error) {
        errorMessage = error.response.data.error;
      }
      Swal.fire("Error!", errorMessage, "error");
    } finally {
      setIsSaving(false); // Set tombol kembali normal setelah selesai
    }
  };
  
  

   useEffect(() => {
      if (isCameraOpen) {
        openCamera();
      }
      return () => {
        stopCamera();
      };
    }, [isCameraOpen, cameraFacingMode]);
  
    useEffect(() => {
      checkCameraAvailability();
      setIsMobile(window.innerWidth <= 768); // Deteksi perangkat (ponsel jika lebar layar <= 768px)
    }, []);
  
    const checkCameraAvailability = async () => {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter((device) => device.kind === "videoinput");
      setIsSwitchCameraAvailable(videoDevices.length > 1); // True jika ada lebih dari satu kamera.
    };
  
    const openCamera = async () => {
      try {
        const newStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: cameraFacingMode },
        });
        setStream(newStream);
      } catch (error) {
        // console.error("Error accessing camera:", error);
        // alert("Tidak dapat mengakses kamera. Pastikan izin kamera telah diberikan.");
      }
    };
  
    const stopCamera = () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
      setStream(null);
    };
  
    const handleCapturePhoto = () => {
      if (!stream) return;
    
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
    
      const video = document.createElement("video");
      video.srcObject = stream;
      video.play();
    
      video.onloadedmetadata = () => {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
    
        // Ambil gambar dari video
        context?.drawImage(video, 0, 0, canvas.width, canvas.height);
    
        // Generate nama file
        const currentDate = new Date();
        const day = String(currentDate.getDate()).padStart(2, "0");
        const month = String(currentDate.getMonth() + 1).padStart(2, "0");
        const year = currentDate.getFullYear();
        const randomString = Math.random().toString(36).substring(2, 8).toUpperCase(); // 6 karakter random
        const fileName = `captured_image_${day}_${month}_${year}_${randomString}.jpg`;
    
        // Convert ke Blob dan File
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], fileName, { type: "image/jpeg" });
            setFormFields((prev) => ({ ...prev, photo: file }));
            setPhotoPreview(URL.createObjectURL(blob));
            setIsCaptureDisabled(true); // Disable tombol "Ambil Gambar" setelah gambar diambil
          }
        });
    
        stopCamera();
        setIsCameraOpen(false);
      };
    };
    
  
  
    const handleSwitchCamera = () => {
      setCameraFacingMode((prev) => (prev === "user" ? "environment" : "user"));
      stopCamera();
      openCamera();
    };
  
    const togglePhotoModal = () => {
      setIsPhotoModalOpen(!isPhotoModalOpen);
      setIsDragAndDropVisible(false); // Tutup drag-and-drop jika ada.
    };
  
    const handlePhotoSelect = (file: File) => {
      setFormFields((prev) => ({ ...prev, photo: file }));
      const reader = new FileReader();
      reader.onload = () => setPhotoPreview(reader.result as string);
      reader.readAsDataURL(file);
      setIsDragAndDropVisible(false);
    };
  
    const handleOpenUpload = () => {
      setIsDragAndDropVisible(true); // Tampilkan area drag-and-drop
      setIsUploadDisabled(true); // Disable tombol upload
      setIsCaptureDisabled(false); // Enable tombol ambil gambar
      setIsPhotoModalOpen(false); // Tutup pop-up "Pilih Foto"
    };
    
    const handleOpenCapture = () => {
      setIsCameraOpen(true); // Buka kamera
      setIsCaptureDisabled(true); // Disable tombol ambil gambar
      setIsUploadDisabled(false); // Enable tombol upload
      setIsPhotoModalOpen(false); // Tutup pop-up "Pilih Foto"
    };

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-8">
      <h1 className="text-3xl font-bold text-center mb-6">Edit Karyawan</h1>
      <form className="space-y-6">
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">NIP</label>
          <input
            type="text"
            value={formFields.employees_nip}
            onChange={(e) => setFormFields({ ...formFields, employees_nip: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          />
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Nama</label>
          <input
            type="text"
            value={formFields.employees_name}
            onChange={(e) => setFormFields({ ...formFields, employees_name: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          />
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Email</label>
          <input
            type="email"
            value={formFields.employees_email}
            onChange={(e) => setFormFields({ ...formFields, employees_email: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          />
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Password</label>
          <input
            type="password"
            value={formFields.password}
            onChange={(e) => setFormFields({ ...formFields, password: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          />
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Jabatan</label>
          <select
            value={formFields.position_id}
            onChange={(e) => setFormFields({ ...formFields, position_id: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          >
            <option value="">Pilih Jabatan</option>
            {positions.map((position) => (
              <option key={position.position_id} value={position.position_id}>
                {position.position_name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Shift</label>
          <select
            value={formFields.shift_id}
            onChange={(e) => setFormFields({ ...formFields, shift_id: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          >
            <option value="">Pilih Shift</option>
            {shifts.map((shift) => (
              <option key={shift.shift_id} value={shift.shift_id}>
                {shift.shift_name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-lg font-medium text-gray-700 mb-2">Penempatan</label>
          <select
            value={formFields.id_area_patroli}
            onChange={(e) => setFormFields({ ...formFields, id_area_patroli: e.target.value })}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          >
            <option value="">Pilih Penempatan</option>
            {penempatan.map((area) => (
              <option key={area.customer_id} value={area.customer_id}>
                {area.name}
              </option>
            ))}
          </select>
        </div>
        <div>
  <label className="block text-lg font-medium text-gray-700 mb-2">Foto</label>
  <button
    type="button"
    onClick={togglePhotoModal}
    className="bg-blue-600 text-white py-2 px-6 rounded-lg hover:bg-blue-700"
  >
    Pilih Foto
  </button>

  {isDragAndDropVisible && (
    <div
      className="border-dashed border-2 border-gray-400 p-4 rounded-lg text-center mt-4"
      onClick={() => document.getElementById("file-input")?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = "copy";
      }}
      onDragEnter={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onDrop={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          handlePhotoSelect(e.dataTransfer.files[0]);
        }
      }}
    >
      <p>Drag and drop file atau klik untuk mengunggah</p>
      <input
        id="file-input"
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files && handlePhotoSelect(e.target.files[0])}
        className="hidden"
      />
    </div>
  )}
   {photoPreview && (
  <img
    src={photoPreview}
    alt="Preview"
    className="mt-4 w-32 h-32 object-cover rounded-md"
  />
)}


        </div>
        <div className="flex justify-between items-center">
  <button
    type="button"
    onClick={handleUpdate}
    className={`bg-blue-600 text-white py-2 px-6 rounded-lg hover:bg-blue-700 ${
      isSaving ? "opacity-50 cursor-not-allowed" : ""
    }`}
    disabled={isSaving} // Disable saat isSaving true
  >
    {isSaving ? "Menyimpan..." : "Simpan Perubahan"}
  </button>
  <button
    type="button"
    onClick={() => navigate("/master-data/karyawan")}
    className="bg-gray-600 text-white py-2 px-6 rounded-lg hover:bg-gray-700"
  >
    Kembali
  </button>
</div>

      </form>

      <Transition appear show={isPhotoModalOpen} as={Fragment}>
        <Dialog onClose={() => setIsPhotoModalOpen(false)} className="relative z-10">
          <div className="fixed inset-0 bg-black bg-opacity-30" />
          <div className="fixed inset-0 flex items-center justify-center p-4">
            <Dialog.Panel className="bg-white p-6 rounded-lg shadow-md max-w-md w-full">
              <Dialog.Title className="text-lg font-bold mb-4">Pilih Foto</Dialog.Title>
              <div className="flex justify-center space-x-4">
                <button
                  type="button"
                  onClick={handleOpenCapture}
                  className={`bg-green-600 text-white py-2 px-6 rounded-lg hover:bg-green-700 ${
                    isCaptureDisabled ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  disabled={isCaptureDisabled} // Disable jika ambil gambar aktif
                >
                  Ambil Gambar
                </button>
      
                <button
                  type="button"
                  onClick={handleOpenUpload}
                  className={`bg-blue-600 text-white py-2 px-6 rounded-lg hover:bg-blue-700 ${
                    isUploadDisabled ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  disabled={isUploadDisabled} // Disable jika upload foto aktif
                >
                  Upload Foto
                </button>
              </div>
              <div className="flex justify-end mt-6">
                <button
                  onClick={() => setIsPhotoModalOpen(false)}
                  className="bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700"
                >
                  Tutup
                </button>
              </div>
            </Dialog.Panel>
          </div>
        </Dialog>
      </Transition>
      
      
            {isCameraOpen && (
              <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex flex-col items-center justify-center">
                <video
                  className={`${
                    isMobile ? "w-3/4" : "w-1/2"
                  } bg-black rounded-md shadow-md`}
                  ref={(ref) => {
                    if (ref && stream) {
                      ref.srcObject = stream;
                      ref.play();
                    }
                  }}
                ></video>
                <div className="mt-4 flex space-x-4">
                  <button
                    onClick={handleCapturePhoto}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                  >
                    Ambil Gambar Sekarang
                  </button>
                  {isSwitchCameraAvailable && isMobile && (
                    <button
                      onClick={handleSwitchCamera}
                      className="bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700"
                    >
                      Ganti Kamera
                    </button>
                  )}
                  <button
                    onClick={() => {
                      stopCamera();
                      setIsCameraOpen(false);
                    }}
                    className="bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700"
                  >
                    Tutup
                  </button>
                </div>
              </div>
            )}
    </div>
  );
};

export default EditEmployee;
