import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [dataCounts, setDataCounts] = useState({
    employees: 0,
    positions: 0,
    customers: 0,
    shifts: 0,
  });
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Ambil data user dari localStorage
    const user = localStorage.getItem("user_data");
    if (user) {
      try {
        setUserData(JSON.parse(user));
      } catch (error) {
        console.error("Gagal mem-parsing user_data:", error);
      }
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      if (!userData) return;

      try {
        const [employeesRes, positionsRes, customersRes, shiftsRes] = await Promise.all([
          axios.get("https://sipandu.sinarjernihsuksesindo.biz.id/api/employees"),
          axios.get("https://sipandu.sinarjernihsuksesindo.biz.id/api/positions"),
          axios.get("https://sipandu.sinarjernihsuksesindo.biz.id/api/customers"),
          axios.get("https://sipandu.sinarjernihsuksesindo.biz.id/api/shifts"),
        ]);

        let filteredEmployees = employeesRes.data;
        let filteredCustomers = customersRes.data;

        // Filter berdasarkan customer_id jika level bukan "2"
        if (userData.level !== "2") {
          const userCustomerId = parseInt(userData.level, 10);

          // Filter data employees dan customers
          filteredEmployees = filteredEmployees.filter(
            (employee) => employee.customer_id === userCustomerId
          );
          filteredCustomers = filteredCustomers.filter(
            (customer) => customer.customer_id === userCustomerId
          );
        }

        setDataCounts({
          employees: filteredEmployees.length,
          positions: positionsRes.data.length,
          customers: filteredCustomers.length,
          shifts: shiftsRes.data.length,
        });
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [userData]);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      {/* Anggota */}
      <div className="bg-blue-500 text-white p-6 rounded-lg shadow-md">
        <h1 className="text-4xl font-bold">{dataCounts.employees}</h1>
        <p className="text-lg mt-2">Anggota</p>
        <a
          href="/master-data/karyawan"
          className="inline-block mt-4 text-blue-200 hover:text-white"
        >
          More info &rarr;
        </a>
      </div>

      {/* Checkpoints */}
      <div className="bg-red-500 text-white p-6 rounded-lg shadow-md">
        <h1 className="text-4xl font-bold">{dataCounts.customers}</h1>
        <p className="text-lg mt-2">Checkpoints</p>
        <a
          href="/master-data/checkpoints"
          className="inline-block mt-4 text-red-200 hover:text-white"
        >
          More info &rarr;
        </a>
      </div>

      {/* Menu lain hanya untuk level 2 */}
      {userData && userData.level === "2" && (
        <>
          <div className="bg-yellow-500 text-white p-6 rounded-lg shadow-md">
            <h1 className="text-4xl font-bold">{dataCounts.positions}</h1>
            <p className="text-lg mt-2">Jabatan</p>
            <a
              href="/master-data/jabatan"
              className="inline-block mt-4 text-yellow-200 hover:text-white"
            >
              More info &rarr;
            </a>
          </div>
          <div className="bg-green-500 text-white p-6 rounded-lg shadow-md">
            <h1 className="text-4xl font-bold">{dataCounts.shifts}</h1>
            <p className="text-lg mt-2">Jam Kerja</p>
            <a
              href="/master-data/shift"
              className="inline-block mt-4 text-green-200 hover:text-white"
            >
              More info &rarr;
            </a>
          </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;
